var myColor = parseInt(document.getElementById("myColorGuess").value);

document.getElementById("runTest").onclick = function() {

  myColor = parseInt(document.getElementById("myColorGuess").value);

  var theCorrectColor;
  var theColor = (Math.floor(Math.random() * 3) + 1);

  document.getElementById("colorReturned").style.display = "block";

  if(theColor == 1){
    theCorrectColor = "Red";
    document.getElementById("colorReturned").style.backgroundColor = "red";

    if(theColor == myColor){
      alert("You're Correct! The color was " + theCorrectColor);
    } else {
      alert("Sorry, you're wrong! The correct color was " + theCorrectColor);
    }

  } else if(theColor == 2){
    theCorrectColor = "Orange";
    document.getElementById("colorReturned").style.backgroundColor = "orange";

    if(theColor == myColor){
      alert("You're Correct! The color was " + theCorrectColor);
    } else {
      alert("Sorry, you're wrong! The correct color was " + theCorrectColor);
    }

  } else {
    theCorrectColor = "Yellow";
    document.getElementById("colorReturned").style.backgroundColor = "yellow";

    if(theColor == myColor){
      alert("You're Correct! The color was " + theCorrectColor);
    } else {
      alert("Sorry, you're wrong! The correct color was " + theCorrectColor);
    }
  }

};